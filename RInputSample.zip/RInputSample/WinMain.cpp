#include <Windows.h>
#include <memory>
#include <sstream>
#include <RInput.h>
#pragma comment(lib, "RInput.lib")

// Global
HINSTANCE g_hInst{};
std::unique_ptr<Keyboard> g_keyboard{};
std::unique_ptr<Mouse> g_mouse{};

// Window Procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	case WM_CREATE:
		try
		{
			// RawInput Initialize
			g_keyboard = std::make_unique<Keyboard>(hwnd);
			g_mouse = std::make_unique<Mouse>(hwnd);
			OutputDebugStringW(L"RInput Initialize.\n");
		}
		catch (const std::exception& e)
		{
			std::wstringstream ws;
			ws << L"Initialization: " << e.what() << std::endl;
			OutputDebugStringW(ws.str().c_str());
			PostQuitMessage(-1);
		}
		return 0;

	case WM_INPUT:
		// RawInput Date
		if (g_keyboard) g_keyboard->ProcessRawInput(lParam);
		if (g_mouse) g_mouse->ProcessRawInput(lParam);
		return 0;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;

	default:
		return DefWindowProc(hwnd, msg, wParam, lParam);
	}
}

int APIENTRY wWinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPWSTR lpCmdLine, _In_ int nCmdShow)
{
	g_hInst = hInstance;

	// Register Window Class
	WNDCLASSEX wcex{};
	wcex.cbSize = sizeof(WNDCLASSEX);
	wcex.style = CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc = WndProc;
	wcex.hInstance = hInstance;
	wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wcex.lpszClassName = L"RInputTestWindow";

	if (!RegisterClassEx(&wcex))
	{
		MessageBox(nullptr, L"failed to window class.", L"ERROR", MB_ICONERROR);
		return -1;
	}

	// Create Window
	HWND hwnd = CreateWindow(L"RInputTestWindow", L"RInputLib",
		WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
		800, 600, nullptr, nullptr, hInstance, nullptr);

	if (!hwnd)
	{
		MessageBox(nullptr, L"failed to create window.", L"ERROR", MB_ICONERROR);
		return -1;
	}

	ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);

	// Main Message
	MSG msg{};
	while (GetMessage(&msg, nullptr, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);

		// Keyboard Pressed
		if (g_keyboard && g_keyboard->IsKeyPressed(KeyCodes::W))
		{
			OutputDebugStringW(L"W Key Pressed.\n");
		}

		// Mouse Button Pressed
		if (g_mouse && g_mouse->IsButtonPressed(MouseButton::Right))
		{
			OutputDebugStringW(L"Right Click Pressed.\n");
		}

		// Get Mouse Position
		if (g_mouse)
		{
			POINT pos = g_mouse->GetMousePosition();
			std::wstringstream ws;
			ws << L"Mouse [X: " << pos.x << L", Y: " << pos.y << L"]" << std::endl;
			OutputDebugStringW(ws.str().c_str());
		}
	}

	return (int)msg.wParam;
}
